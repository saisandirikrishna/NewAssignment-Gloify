import { UserClass } from './user-class';

describe('UserClass', () => {
  it('should create an instance', () => {
    expect(new UserClass()).toBeTruthy();
  });
});
